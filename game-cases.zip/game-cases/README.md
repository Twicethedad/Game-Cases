# Game Cases

A Decky Loader plugin for SteamOS handhelds (Steam Deck, Legion Go S and similar).

It draws a real console case around the library artwork of every game in your collections, live.
A PS2 collection gets PS2 cases, an Xbox 360 collection gets Xbox 360 cases, and so on.

Nothing is written to your artwork. The cases are drawn over the top: switch "Show cases" off, or
uninstall, and your library looks exactly as it did before.

## Install

1. Decky settings > General > turn on **Developer mode**
2. Decky settings > **Developer** > **Install plugin from ZIP** > choose `game-cases.zip`
3. Restart Steam (power menu, or reboot)

## Use

Quick Access (the "..." button) > plug icon > **Game Cases**

- **Collections**: collections named PS2, PS3, PS4, Xbox 360, GameCube, Wii, Wii U, Switch and Steam
  are matched to their case automatically. Every collection also has a dropdown, so you can choose a
  different case or "No case".
- **Show cases**: turns every case on or off instantly.
- **Steam case for other Steam games**: puts the Steam case on Steam games that aren't in a cased
  collection. Non-Steam shortcuts (emulators, apps) never get it unless you choose it for them.
- **Art drop**: how far the cover slides down behind the case's top banner. 50% is the default:
  a little of the top hides behind the banner, a little is trimmed off the bottom.
- **Original case headers**: off by default, so every case has the same banner height and matching
  logo sizes. Turn it on to use each console's original banner instead.
- New games added to a collection get their case within about 30 seconds.

## What works alongside it

- **CSS Loader themes**, including "Round": cased tiles keep the case's own corners, everything else
  stays as the theme draws it.
- **TabMaster**: tabs and cases work together.
- **Game Glance**: its home-screen cards get cases too. The wide banner for the selected game keeps
  Game Glance's own artwork.
- **Finally 3D Game Cases**: not compatible. It takes over the focused tile to tilt it in 3D, so the
  focused game loses its case while it is installed.

This plugin never rewrites Steam's own pages. It marks the tiles it cases and draws everything with a
stylesheet, which is why it sits alongside other plugins and themes safely.

It also corrects a Decky bug (3.2.x) that crashes the library with React error #130 after switching
from Desktop Mode back to Game Mode. That fix only applies while this plugin is enabled.

## Add or swap a case

Put a **600 x 900 PNG** in `~/homebrew/settings/game-cases/frames/`, transparent wherever the cover
art should show through. Name it after the case it replaces:

    steam.png  ps2.png  ps3.png  ps4.png  xbox360.png  gamecube.png  wii.png  wiiu.png  switch.png

Optionally add a matching `.json`:

    {"label": "PS2", "strip": 104}

`label` is the name shown in the settings, `strip` is the height in pixels of the case's top banner.
The cover opening is traced automatically, so art never shows outside the case. Restart Steam after
adding files.

Templates for most consoles can be found by searching for "<console> case template PNG". Make sure
the cover area is see-through rather than white.

## Build from source

    npm install
    npm run build

## Credits and licence

MIT. The case templates bundled with the plugin are community-made console case templates; the
console names and logos on them belong to their respective owners.
