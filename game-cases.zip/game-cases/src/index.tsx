import { callable, definePlugin } from "@decky/api";
import {
  ButtonItem,
  DropdownItem,
  PanelSection,
  PanelSectionRow,
  SliderField,
  ToggleField,
  findSP,
  staticClasses,
} from "@decky/ui";
import { Component, useEffect, useState } from "react";
import { FaCompactDisc } from "react-icons/fa";

/*
 * Design note (v1.3): the plugin never inserts, moves or removes elements in Steam's UI.
 * React (and plugins like TabMaster that patch the library) own those elements, and foreign
 * child nodes can make React's updates fail. Instead, a tile is marked with a data attribute
 * plus one CSS variable, and the case + art are drawn by a single stylesheet using ::before/::after.
 */

// ---------------- backend ----------------
type RawFrame = { name: string; label: string; strip: number; data: string; box?: [number, number, number, number] };
type Frame = RawFrame & { box: [number, number, number, number]; url?: string; bytes?: Uint8Array }; // box: cover opening in 600x900; url: blob URL of the case image
type Config = { enabled: boolean; mappings: Record<string, string>; steamFallback: boolean; drop: number; classic?: boolean };
const getConfig = callable<[], Config>("get_config");
const setConfig = callable<[Config], boolean>("set_config");
const listFrames = callable<[boolean], RawFrame[]>("list_frames");

declare const collectionStore: any;

/*
 * Steam's collection list must not be read before Steam has built it. Reading it too early makes Steam's
 * own (MobX) "userCollections" value fail, and Steam then remembers that failure and shows it in its own
 * screens too, which is the Decky error naming Game Cases. So the plugin first checks, without touching
 * that value, that the collection data underneath exists. Until then it simply waits.
 */
const loadedAt = Date.now();
function storeReady(): boolean {
  try {
    if (Date.now() - loadedAt > 30000) return true; // Steam has long finished starting by now
    const cs = (window as any).collectionStore;
    if (!cs) return false;
    for (const k of Object.keys(cs)) {
      if (!/collection/i.test(k)) continue;
      const v = cs[k];
      if (v && typeof v.values === "function" && typeof v.size === "number" && v.size > 0) return true;
    }
    return false;
  } catch {
    return false;
  }
}
declare const appStore: any;

let cfg: Config = { enabled: true, mappings: {}, steamFallback: true, drop: 50 };
let frames: Frame[] = [];

// ---------------- cover opening of a template ----------------
async function openingBox(b64: string): Promise<[number, number, number, number]> {
  const img = new Image();
  img.src = `data:image/png;base64,${b64}`;
  await img.decode();
  const W = img.naturalWidth, H = img.naturalHeight;
  const cv = document.createElement("canvas");
  cv.width = W;
  cv.height = H;
  const ctx = cv.getContext("2d")!;
  ctx.drawImage(img, 0, 0);
  const px = ctx.getImageData(0, 0, W, H).data;
  const a = (i: number) => px[i * 4 + 3];
  let seed = -1;
  for (let y = Math.floor((H * 2) / 3); y < H && seed < 0; y++) if (a(y * W + (W >> 1)) < 10) seed = y * W + (W >> 1);
  if (seed < 0) return [0, 0, 600, 900];
  const seen = new Uint8Array(W * H), q = new Int32Array(W * H);
  let h = 0, t = 0, x0 = W, y0 = H, x1 = 0, y1 = 0;
  q[t++] = seed;
  seen[seed] = 1;
  while (h < t) {
    const i = q[h++], x = i % W, y = (i / W) | 0;
    if (x < x0) x0 = x;
    if (x > x1) x1 = x;
    if (y < y0) y0 = y;
    if (y > y1) y1 = y;
    for (const j of [x > 0 ? i - 1 : -1, x < W - 1 ? i + 1 : -1, i - W, i + W]) {
      if (j < 0 || j >= W * H || seen[j] || a(j) >= 10) continue;
      seen[j] = 1;
      q[t++] = j;
    }
  }
  // 2px under the case's inner edge so it blends with no hairline
  const sx = 600 / W, sy = 900 / H;
  return [Math.max(0, (x0 - 2) * sx), Math.max(0, (y0 - 2) * sy), Math.min(600, (x1 + 3) * sx), Math.min(900, (y1 + 3) * sy)];
}

// ---------------- collection -> case ----------------
function autoFrame(name: string): string | null {
  const n = name.toLowerCase().replace(/[^a-z0-9]/g, "");
  const rules: [RegExp, string][] = [
    [/wiiu/, "wiiu"],
    [/wii/, "wii"],
    [/^(ps2|playstation2)$/, "ps2"],
    [/^(ps3|playstation3)$/, "ps3"],
    [/^(ps4|playstation4)$/, "ps4"],
    [/xbox360|^360$/, "xbox360"],
    [/gamecube|^gc$|^ngc$/, "gamecube"],
    [/switch/, "switch"],
    [/^steam$/, "steam"],
  ];
  const hit = rules.find(([re]) => re.test(n));
  return hit && frames.some((f) => f.name === hit[1]) ? hit[1] : null;
}

type Coll = { id: string; name: string; count: number; appids: number[] };
function getCollections(): Coll[] {
  try {
    if (!storeReady()) return [];
    return (collectionStore?.userCollections ?? [])
      .map((c: any) => {
        const appids = (c.allApps ?? []).map((x: any) => Number(x.appid));
        return { id: String(c.id), name: String(c.displayName ?? c.id), count: appids.length, appids };
      })
      .sort((x: Coll, y: Coll) => x.name.localeCompare(y.name));
  } catch {
    return [];
  }
}

let lastSig = "";
function collectionsSignature(): string {
  try {
    if (!storeReady()) return "";
    return (collectionStore?.userCollections ?? []).map((c: any) => `${c.id}:${c.allApps?.length ?? 0}`).join("|");
  } catch {
    return "";
  }
}

let appFrames = new Map<number, string>();
const fallbackCache = new Map<number, string | null>();
// Last known games per collection. Steam/TabMaster can briefly report a collection as empty
// (or not at all) while recalculating; that must never switch cases off.
const lastKnown = new Map<string, Coll>();
function rebuildMap() {
  const now = getCollections();
  if (now.length === 0 && lastKnown.size > 0) return; // store not ready: keep current cases
  for (const c of now) {
    const prev = lastKnown.get(c.id);
    if (c.count === 0 && prev && prev.count > 0) continue; // transient empty: keep previous games
    lastKnown.set(c.id, c);
  }
  const next = new Map<number, string>();
  for (const c of lastKnown.values()) {
    const m = cfg.mappings[c.id];
    const f = m === "none" ? null : m ?? autoFrame(c.name);
    if (!f) continue;
    for (const id of c.appids) if (!next.has(id)) next.set(id, f);
  }
  appFrames = next;
  fallbackCache.clear();
}

function frameForApp(appid: number): string | null {
  const f = appFrames.get(appid);
  if (f) return f;
  if (!cfg.steamFallback || appid <= 0 || appid >= 0x80000000) return null;
  if (!fallbackCache.has(appid)) {
    let r: string | null = null;
    try {
      const ov = appStore?.GetAppOverviewByAppID?.(appid);
      r = ov && ov.app_type === 1 && frames.some((x) => x.name === "steam") ? "steam" : null;
    } catch {}
    fallbackCache.set(appid, r);
  }
  return fallbackCache.get(appid)!;
}

// ---------------- recognising game covers ----------------
const PATTERNS = [
  /\/assets\/(\d+)\/[^?#]*library_(?:600x900|capsule)/,
  /\/apps\/(\d+)\/[^?#]*library_(?:600x900|capsule)/,
  /\/customimages\/(\d+)p\.(?:png|jpe?g|webp)/,
];
function appidFromSrc(src: string): number | null {
  for (const re of PATTERNS) {
    const m = re.exec(src);
    if (m) return Number(m[1]);
  }
  return null;
}

function fiberOf(el: Element): any {
  const key = Object.keys(el).find((k) => k.startsWith("__reactFiber$") || k.startsWith("__reactInternalInstance$"));
  return key ? (el as any)[key] : null;
}
const ID_KEY = /^(n|un|str)?app_?id$/i;
function idFromProps(p: any, level = 0): number | null {
  if (!p || typeof p !== "object" || level > 1) return null;
  try {
    for (const k of Object.keys(p)) if (ID_KEY.test(k) && Number(p[k]) > 0) return Number(p[k]);
    for (const k of ["app", "overview", "appOverview", "game", "item", "data"]) {
      const n = idFromProps(p[k], level + 1);
      if (n) return n;
    }
  } catch {}
  return null;
}
// read-only look at the tile's React props, for plugins that draw their own tiles
function appidFromReact(el: Element): number | null {
  let f: any = fiberOf(el);
  for (let d = 0; f && d < 25; d++, f = f.return) {
    const n = idFromProps(f.memoizedProps);
    if (n) return n;
  }
  return null;
}
// per-image cache so each cover is only examined once per image address
const seenSrc = new WeakMap<HTMLImageElement, { src: string; id: number | null; viaReact: boolean }>();
const candidates = new Set<HTMLImageElement>(); // recognised games without a case (yet)

function recognise(img: HTMLImageElement, src: string): { id: number | null; viaReact: boolean } {
  const c = seenSrc.get(img);
  if (c && c.src === src) return c;
  // Only Steam's own cover images (recognised by their address) are cased. Tiles drawn by other
  // plugins (e.g. Game Glance) are left completely untouched.
  const id = appidFromSrc(src), viaReact = false;
  const r = { src, id, viaReact };
  seenSrc.set(img, r);
  return r;
}

function isPortrait(img: HTMLImageElement): boolean | null {
  if (!img.complete || !img.naturalWidth) return null;
  const r = img.naturalHeight / img.naturalWidth;
  return r > 1.3 && r < 1.7;
}

// ---------------- drawing (CSS only) ----------------
const STYLE_ID = "game-cases-style";
const ATTR = "data-gamecase";
let doc: Document | null = null;
let observer: MutationObserver | null = null;
let timer: number | undefined;
const tracked = new Set<HTMLImageElement>();
const marked = new WeakMap<HTMLImageElement, HTMLElement>(); // img -> host it marked
const pending = new Set<HTMLImageElement>();
let scheduled = false;

function writeStyle() {
  if (!doc) return;
  let el = doc.getElementById(STYLE_ID) as HTMLStyleElement | null;
  if (!el) {
    el = doc.createElement("style");
    el.id = STYLE_ID;
    doc.head.appendChild(el);
  }
  const H = `html body [${ATTR}][${ATTR}]`;
  const r = [
    `${H}:not(.gh-cap){position:relative!important}`,
    `${H}{border-radius:0!important}`,
    // Game Glance cards: hide their own cover layers; keep its badge and focus bar above the case
    `${H}>.gh-cap-cover,${H}>.gh-cap-blur{opacity:0!important}`,
    `${H}>.gh-cap-new,${H}>.gh-cap-bar,${H}>.gh-ghost-badge{z-index:3!important}`,
    // the selected card turns into a wide banner: show Game Glance's own art there, no case
    `${H}.gh-cap-wide::before,${H}.gh-cap-wide::after{display:none!important}`,
    `${H}.gh-cap-wide>.gh-cap-cover,${H}.gh-cap-wide>.gh-cap-blur{opacity:1!important}`,
    `${H}.gh-cap-wide{border-radius:revert!important}`,
    `${H}>img{opacity:0!important;visibility:hidden!important}`,
    `${H}::before,${H}::after{content:""!important;position:absolute!important;left:0!important;width:100%!important;height:100%!important;pointer-events:none!important;background-repeat:no-repeat!important;background-size:100% 100%!important;border-radius:0!important;display:block!important;opacity:1!important}`,
    `${H}::before{background-image:var(--gamecase-art)!important;z-index:1!important}`,
    `${H}::after{top:0!important;z-index:2!important}`,
  ];
  for (const f of frames) {
    const [x0, y0, x1, y1] = f.box;
    const d = Math.min((f.strip * cfg.drop) / 100, y0); // never leave a gap above the art
    const pct = (v: number, of: number) => ((v / of) * 100).toFixed(3) + "%";
    const sel = `html body [${ATTR}="${f.name}"][${ATTR}="${f.name}"]`;
    const img = f.url ?? (f.data ? `data:image/png;base64,${f.data}` : "");
    if (img) r.push(`${sel}::after{background-image:url(${img})!important}`);
    // art: dropped by d, trimmed to the cover opening (coordinates are in the dropped box)
    r.push(
      `${sel}::before{top:${pct(d, 900)}!important;clip-path:inset(${pct(Math.max(0, y0 - d), 900)} ${pct(600 - x1, 600)} ${pct(Math.max(0, 900 - (y1 - d)), 900)} ${pct(x0, 600)})!important}`,
    );
  }
  el.textContent = r.join("\n");
}

const hostImg = new WeakMap<HTMLElement, HTMLImageElement>();
let hostObserver: MutationObserver | null = null;

function unmark(img: HTMLImageElement) {
  const host = marked.get(img);
  if (host) {
    hostImg.delete(host);
    host.removeAttribute(ATTR);
    host.style.removeProperty("--gamecase-art");
  }
  marked.delete(img);
  tracked.delete(img);
}

function apply(img: HTMLImageElement) {
  try {
    if (!img.isConnected) {
      candidates.delete(img);
      return unmark(img);
    }
    const src = img.currentSrc || img.src || "";
    const { id, viaReact } = cfg.enabled ? recognise(img, src) : { id: null, viaReact: false };
    const frame = id != null ? frameForApp(id) : null;
    if (id != null && !frame) candidates.add(img);
    else candidates.delete(img);
    const host = img.parentElement;
    const prev = marked.get(img);
    if (prev && prev !== host) unmark(img);
    if (!frame || !host) return marked.has(img) ? unmark(img) : undefined;
    // tiles drawn by other plugins: only case them if the tile box is the image itself
    // (checked once per tile; Steam's own covers skip this so there's no layout work)
    if (viaReact && !marked.has(img)) {
      const w = img.offsetWidth, h = img.offsetHeight;
      if (!w || !h || Math.abs(host.clientWidth - w) > 4 || Math.abs(host.clientHeight - h) > 4) return;
    }
    const art = `url("${src.replace(/"/g, '\\"')}")`;
    if (host.getAttribute(ATTR) !== frame) host.setAttribute(ATTR, frame);
    if (host.style.getPropertyValue("--gamecase-art") !== art) host.style.setProperty("--gamecase-art", art);
    if (marked.get(img) !== host) {
      hostImg.set(host, img);
      hostObserver?.observe(host, { attributes: true, attributeFilter: [ATTR, "style"] });
    }
    marked.set(img, host);
    tracked.add(img);
  } catch (e) {
    console.error("Game Cases:", e); // never let an error escape into Steam's UI
  }
}

function queue(img: HTMLImageElement) {
  pending.add(img);
  if (scheduled) return;
  scheduled = true;
  (doc?.defaultView ?? window).requestAnimationFrame(flush);
}

function flush() {
  scheduled = false;
  const list = [...pending];
  pending.clear();
  for (const i of list) apply(i);
  const cards = [...pendingCards];
  pendingCards.clear();
  for (const c of cards) applyCard(c);
}

// ---------------- Game Glance home screen ----------------
// Game Glance draws its recents row as <div class="gh-cap"> cards whose cover is a CSS background
// on a child <div class="gh-cap-cover"> (no <img>), so those cards are handled here.
const CARD = ".gh-cap:not(.gh-cap-lib)";
const trackedCards = new Set<HTMLElement>();
const pendingCards = new Set<HTMLElement>();

function cardIds(card: HTMLElement, bg: string): { fromUrl: number | null; fromGame: number | null } {
  let fromUrl: number | null = null, fromGame: number | null = null;
  for (const m of bg.matchAll(/url\(["']?([^"')]+)["']?\)/g)) {
    const id = appidFromSrc(m[1]);
    if (id != null) { fromUrl = id; break; }
  }
  // GameCapsule's own props ({ game: { appId } }), looked at only a few levels up
  let f: any = fiberOf(card);
  for (let d = 0; f && d < 4; d++, f = f.return) {
    const id = Number(f.memoizedProps?.game?.appId);
    if (id > 0) { fromGame = id; break; }
  }
  return { fromUrl, fromGame };
}
function cardFrame(card: HTMLElement, bg: string): string | null {
  const { fromUrl, fromGame } = cardIds(card, bg);
  // Game Glance's id is the one Steam's collections use, so it goes first
  for (const id of [fromGame, fromUrl]) if (id != null) { const f = frameForApp(id); if (f) return f; }
  return null;
}

function applyCard(card: HTMLElement) {
  try {
    if (!card.isConnected) {
      trackedCards.delete(card);
      return;
    }
    const cover = card.querySelector(":scope > .gh-cap-cover") as HTMLElement | null;
    const bg = cover?.style.backgroundImage ?? "";
    const frame = cfg.enabled && bg ? cardFrame(card, bg) : null;
    if (!frame) {
      if (card.hasAttribute(ATTR)) {
        card.removeAttribute(ATTR);
        card.style.removeProperty("--gamecase-art");
      }
      trackedCards.delete(card);
      return;
    }
    if (card.getAttribute(ATTR) !== frame) card.setAttribute(ATTR, frame);
    if (card.style.getPropertyValue("--gamecase-art") !== bg) card.style.setProperty("--gamecase-art", bg);
    if (!trackedCards.has(card)) {
      trackedCards.add(card);
      hostObserver?.observe(card, { attributes: true, attributeFilter: [ATTR, "style"] });
    }
  } catch (e) {
    console.error("Game Cases card:", e);
  }
}

function queueCard(card: HTMLElement) {
  pendingCards.add(card);
  if (scheduled) return;
  scheduled = true;
  (doc?.defaultView ?? window).requestAnimationFrame(flush);
}

function scanCards(root: ParentNode) {
  root.querySelectorAll?.(CARD).forEach((c) => queueCard(c as HTMLElement));
}

let sp: any = null;
let watchdog: number | undefined;

function makeUrls() {
  for (const f of frames) {
    try {
      if (!f.bytes) {
        const bin = atob(f.data);
        f.bytes = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) f.bytes[i] = bin.charCodeAt(i);
        f.data = "";
      }
      // blob URLs belong to Steam's window, so they're remade whenever that window is
      f.url = sp.URL.createObjectURL(new sp.Blob([f.bytes], { type: "image/png" }));
    } catch {
      f.url = undefined;
    }
  }
}

function attach() {
  sp = findSP();
  if (!sp?.document?.body) {
    timer = window.setTimeout(attach, 2000);
    return;
  }
  doc = sp.document;
  makeUrls();
  writeStyle();
  lastSig = collectionsSignature();
  rebuildMap();
  doc!.querySelectorAll("img").forEach((i) => queue(i as HTMLImageElement));
  // Steam may still be loading its collections: check every second, then case everything straight away
  if (!lastSig) {
    const wait = window.setInterval(() => {
      if (!storeReady() || !doc) return;
      clearInterval(wait);
      lastSig = collectionsSignature();
      rebuildMap();
      doc.querySelectorAll("img").forEach((i) => queue(i as HTMLImageElement));
      scanCards(doc);
    }, 1000);
  }
  scanCards(doc!);
  observer = new sp.MutationObserver((muts: MutationRecord[]) => {
    for (const m of muts) {
      if (m.type === "attributes") {
        if (m.target.nodeName === "IMG") queue(m.target as HTMLImageElement);
        continue;
      }
      m.addedNodes.forEach((n) => {
        if (n.nodeType !== 1) return;
        if (n.nodeName === "IMG") queue(n as HTMLImageElement);
        else {
          const el = n as Element;
          const imgs = el.getElementsByTagName("img");
          for (let k = 0; k < imgs.length; k++) queue(imgs[k] as HTMLImageElement);
          if (el.matches?.(CARD)) queueCard(el as HTMLElement);
          else if (el.getElementsByClassName("gh-cap").length) scanCards(el);
        }
      });
    }
  });
  observer!.observe(doc!.body, { childList: true, subtree: true, attributes: true, attributeFilter: ["src"] });
  hostObserver = new sp.MutationObserver((muts: MutationRecord[]) => {
    for (const m of muts) {
      const host = m.target as HTMLElement;
      const img = hostImg.get(host);
      if (!img && trackedCards.has(host) && (!host.hasAttribute(ATTR) || !host.style.getPropertyValue("--gamecase-art"))) {
        queueCard(host);
        continue;
      }
      if (img && (!host.hasAttribute(ATTR) || !host.style.getPropertyValue("--gamecase-art"))) {
        const s = seenSrc.get(img);
        if (s) s.src = ""; // force a fresh check
        marked.delete(img);
        queue(img);
      }
    }
  });
  timer = window.setInterval(() => {
    for (const i of candidates) if (!i.isConnected) candidates.delete(i);
    for (const i of tracked) if (!i.isConnected) unmark(i);
    const sig = collectionsSignature();
    if (sig === lastSig) return;
    lastSig = sig;
    rebuildMap();
    for (const i of [...tracked, ...candidates]) queue(i);
    scanCards(doc!);
  }, 30000);
}

function detach(removeMarks: boolean) {
  observer?.disconnect();
  hostObserver?.disconnect();
  observer = hostObserver = null;
  if (timer) {
    clearInterval(timer);
    clearTimeout(timer);
  }
  timer = undefined;
  if (removeMarks) {
    for (const i of [...tracked]) unmark(i);
    for (const c of trackedCards) {
      c.removeAttribute(ATTR);
      c.style.removeProperty("--gamecase-art");
    }
  }
  trackedCards.clear();
  tracked.clear();
  candidates.clear();
  doc?.getElementById(STYLE_ID)?.remove();
  for (const f of frames) if (f.url) sp?.URL?.revokeObjectURL(f.url);
  doc = null;
}

// Self-healing check every 10s (tiny: a couple of comparisons plus the visible cased tiles).
// Keeps cases on however long a screen is left open: Steam rebuilding its window after sleep or a
// mode switch, something removing the stylesheet, or a tile losing its marker all get repaired.
function heal() {
  try {
    // Only reconnect if Steam's window has really closed. (Asking Decky for "the" Steam window can
    // return a different window, e.g. while Quick Access is open; the old check reacted to that and
    // removed the cases. That was the cause of cases switching off.)
    if (!doc || !doc.defaultView || doc.defaultView.closed) {
      detach(false);
      attach();
      return;
    }
    const style = doc.getElementById(STYLE_ID);
    if (!style || !style.isConnected || !style.textContent) writeStyle();
    for (const img of tracked) {
      const host = marked.get(img);
      if (img.isConnected && host && (!host.hasAttribute(ATTR) || !host.style.getPropertyValue("--gamecase-art"))) {
        marked.delete(img);
        queue(img);
      }
    }
    doc.querySelectorAll(`${CARD}:not([${ATTR}])`).forEach((c) => queueCard(c as HTMLElement));
  } catch (e) {
    console.error("Game Cases heal:", e);
  }
}

function start() {
  attach();
  watchdog = window.setInterval(heal, 10000);
}

function stop() {
  if (watchdog) clearInterval(watchdog);
  detach(true);
}

function refresh(styleChanged: boolean) {
  if (styleChanged) return writeStyle(); // drop slider: CSS only, no tile work
  rebuildMap();
  doc?.querySelectorAll("img").forEach((i) => queue(i as HTMLImageElement));
  if (doc) scanCards(doc);
}


// ---------------- diagnostics ----------------
function diagnose(): string[] {
  if (!doc) return ["Steam UI not found yet"];
  const imgs = [...doc.querySelectorAll("img")] as HTMLImageElement[];
  let portrait = 0, byUrl = 0, byReact = 0, cased = 0, notTight = 0;
  const misses: string[] = [];
  for (const img of imgs) {
    if (marked.has(img)) cased++;
    const p = isPortrait(img);
    if (p) portrait++;
    const src = img.currentSrc || img.src || "";
    const id = appidFromSrc(src) ?? (p ? appidFromReact(img) : null);
    if (appidFromSrc(src) != null) byUrl++;
    else if (id) byReact++;
    if (id && !marked.has(img) && frameForApp(id)) notTight++;
    if (p && !id && misses.length < 3) {
      const keys: string[] = [];
      let f = fiberOf(img);
      for (let d = 0; f && d < 8 && keys.length < 10; d++, f = f.return) {
        const pr = f.memoizedProps;
        if (pr && typeof pr === "object") for (const k of Object.keys(pr)) if (!keys.includes(k) && k !== "children") keys.push(k);
      }
      misses.push(`${src.slice(0, 70)} | props: ${keys.join(",") || "none"}`);
    }
  }
  const bg = [...doc.querySelectorAll("[style*='background-image']")].filter((e) => {
    const el = e as HTMLElement;
    return el.offsetWidth > 0 && el.offsetHeight / el.offsetWidth > 1.3;
  }).length;
  const cards = [...doc.querySelectorAll(CARD)] as HTMLElement[];
  const cardLines: string[] = [`Game Glance cards ${cards.length} | cased ${cards.filter((c) => c.hasAttribute(ATTR)).length} | collections ${appFrames.size} games`];
  for (const c of cards) {
    if (c.hasAttribute(ATTR) || c.classList.contains("gh-cap-wide") || cardLines.length > 4) continue;
    const bg = (c.querySelector(":scope > .gh-cap-cover") as HTMLElement | null)?.style.backgroundImage ?? "";
    const { fromUrl, fromGame } = cardIds(c, bg);
    let name = "";
    try { name = String(appStore?.GetAppOverviewByAppID?.(fromGame ?? fromUrl ?? 0)?.display_name ?? "").slice(0, 18); } catch {}
    cardLines.push(`uncased "${name}" game ${fromGame} (${fromGame != null ? frameForApp(fromGame) ?? "no case" : "-"}) addr ${fromUrl} | ${bg.slice(0, 60) || "no cover"}`);
  }
  return [
    ...cardLines,
    `v1.8.1 | images ${imgs.length} | tall ${portrait} | cased ${cased}`,
    `found by address ${byUrl} | by tile ${byReact} | found but skipped ${notTight}`,
    `tall backgrounds ${bg} | frames ${doc.querySelectorAll("iframe").length}`,
    ...misses.map((m, i) => `miss ${i + 1}: ${m}`),
  ];
}

// ---------------- Desktop -> Game Mode fix (Decky route-patch state) ----------------
// Decky 3.2.x remembers the original content of every patched page (routerHook.toReplace) and puts it
// back before re-applying plugin patches. It keeps the FIRST copy it ever saw: when Game Mode's UI is
// rebuilt (switching back from Desktop Mode), it injects the old session's Home page into the new one,
// which React rejects (error #130) until Steam restarts. Game Glance patches Home, so that's where it shows.
// Fix: whenever Steam hands Decky a fresh, unpatched page, drop the remembered copy first so Decky
// saves the fresh one. Pages Decky already patched are left alone, so unpatching still works.
let routerFixUndo: (() => void) | null = null;
function installRouterFix() {
  try {
    const rh = (window as any).DeckyPluginLoader?.routerHook;
    if (!rh || typeof rh.processList !== "function" || !(rh.toReplace instanceof Map) || rh.__gameCasesFix) return;
    const orig = rh.processList;
    const isPatchedByDecky = (el: any) =>
      Object.getOwnPropertySymbols(el).some((sym) => sym.description === "is patched");
    rh.processList = function (routeList: any[], ...rest: any[]) {
      try {
        if (Array.isArray(routeList))
          for (const r of routeList) {
            const path = r?.props?.path, el = r?.props?.children;
            if (typeof path === "string" && el && typeof el === "object" && !isPatchedByDecky(el)) this.toReplace?.delete(path);
          }
      } catch {}
      return orig.call(this, routeList, ...rest);
    };
    rh.__gameCasesFix = true;
    routerFixUndo = () => {
      rh.processList = orig;
      delete rh.__gameCasesFix;
    };
  } catch (e) {
    console.error("Game Cases: router fix not applied", e);
  }
}

// ---------------- Quick Access panel ----------------
// React error #130 ("element type is invalid") happens when a UI component can't be found in the
// current Steam build. Every component is checked, with a plain fallback, and the whole panel sits
// inside an error boundary, so this plugin can never take down Decky's menu.
const valid = (C: any) => typeof C === "function" || (!!C && typeof C === "object" && "$$typeof" in C);
const SafeButton = (p: { onClick: () => void; children: any }) =>
  valid(ButtonItem) ? <ButtonItem layout="below" onClick={p.onClick}>{p.children}</ButtonItem> : <button onClick={p.onClick}>{p.children}</button>;
const SafeToggle = (p: { label: string; description?: string; checked: boolean; onChange: (v: boolean) => void }) =>
  valid(ToggleField) ? (
    <ToggleField label={p.label} description={p.description} checked={p.checked} onChange={p.onChange} />
  ) : (
    <label style={{ display: "block" }}>
      <input type="checkbox" checked={p.checked} onChange={(e) => p.onChange((e.target as HTMLInputElement).checked)} /> {p.label}
    </label>
  );
const SafeSection = (p: { title?: string; children: any }) =>
  valid(PanelSection) ? <PanelSection title={p.title}>{p.children}</PanelSection> : <div>{p.title && <h3>{p.title}</h3>}{p.children}</div>;
const SafeRow = (p: { children: any; key?: any }) => (valid(PanelSectionRow) ? <PanelSectionRow>{p.children}</PanelSectionRow> : <div>{p.children}</div>);

class Guard extends Component<{ children: any }, { err: string | null }> {
  state = { err: null as string | null };
  static getDerivedStateFromError(e: any) {
    return { err: String(e?.message ?? e).slice(0, 160) };
  }
  componentDidCatch(e: any) {
    console.error("Game Cases panel error:", e);
  }
  render() {
    if (this.state.err)
      return (
        <div style={{ padding: "8px", fontSize: "12px" }}>
          Game Cases settings couldn't load on this Steam version. Cases still work.
          <br />
          {this.state.err}
        </div>
      );
    return this.props.children;
  }
}

function Content() {
  const [colls, setColls] = useState<Coll[]>([]);
  const [, force] = useState(0);
  const [diag, setDiag] = useState<string[]>([]);
  useEffect(() => setColls(getCollections()), []);

  const update = (patch: Partial<Config>, styleChanged = false) => {
    cfg = { ...cfg, ...patch };
    force((x) => x + 1);
    setConfig(cfg);
    refresh(styleChanged);
  };

  const options = (c: Coll) => {
    const auto = autoFrame(c.name);
    return [
      { data: "auto", label: auto ? `Auto (${frames.find((f) => f.name === auto)?.label})` : "Auto (no match)" },
      { data: "none", label: "No case" },
      ...frames.map((f) => ({ data: f.name, label: f.label })),
    ];
  };

  return (
    <>
      <SafeSection>
        <SafeRow>
          <SafeToggle label="Show cases" checked={cfg.enabled} onChange={(v: boolean) => update({ enabled: v })} />
        </SafeRow>
        {valid(SliderField) && <SafeRow>
          <SliderField
            label="Art drop"
            description="How far the cover drops below the case's top strip"
            value={cfg.drop}
            min={0}
            max={100}
            step={5}
            valueSuffix="%"
            showValue
            resetValue={50}
            onChange={(v: number) => update({ drop: v }, true)}
          />
        </SafeRow>}
        <SafeRow>
          <SafeToggle
            label="Original case headers"
            description="Off: every case's header matches Steam's height. On: each console's original header."
            checked={!!cfg.classic}
            onChange={(v: boolean) => {
              force((x) => x + 1);
              switchStyle(v);
            }}
          />
        </SafeRow>
        <SafeRow>
          <SafeToggle
            label="Steam case for other Steam games"
            description="Steam games that aren't in any cased collection"
            checked={cfg.steamFallback}
            onChange={(v: boolean) => update({ steamFallback: v })}
          />
        </SafeRow>
      </SafeSection>
      <SafeSection title="Troubleshooting">
        <SafeRow>
          <SafeButton onClick={() => setDiag(diagnose())}>Check this screen</SafeButton>
        </SafeRow>
        {diag.length > 0 && (
          <SafeRow>
            <div style={{ fontSize: "11px", lineHeight: "15px", wordBreak: "break-all" }}>
              {diag.map((l, i) => (
                <div key={i}>{l}</div>
              ))}
            </div>
          </SafeRow>
        )}
      </SafeSection>
      <SafeSection title="Collections">
        {colls.length === 0 && <SafeRow>No collections found.</SafeRow>}
        {valid(DropdownItem) && colls.map((c) => (
          <SafeRow key={c.id}>
            <DropdownItem
              label={`${c.name} (${c.count})`}
              rgOptions={options(c)}
              selectedOption={cfg.mappings[c.id] ?? "auto"}
              onChange={(o: any) => {
                const m = { ...cfg.mappings };
                if (o.data === "auto") delete m[c.id];
                else m[c.id] = o.data;
                update({ mappings: m });
              }}
            />
          </SafeRow>
        ))}
      </SafeSection>
    </>
  );
}

async function loadFrames() {
  const raw = await listFrames(!!cfg.classic);
  const next: Frame[] = [];
  for (const f of raw) {
    try {
      next.push({ ...f, box: f.box ?? (await openingBox(f.data)) }); // bundled cases ship their box
    } catch (e) {
      console.error("Game Cases: bad template", f.name, e);
    }
  }
  return next;
}

async function switchStyle(classic: boolean) {
  cfg = { ...cfg, classic };
  setConfig(cfg);
  const next = await loadFrames();
  for (const f of frames) if (f.url) sp?.URL?.revokeObjectURL(f.url);
  frames = next;
  if (sp) makeUrls();
  writeStyle();
}

export default definePlugin(() => {
  installRouterFix();
  (async () => {
    try {
      cfg = await getConfig();
      frames = await loadFrames();
      start();
    } catch (e) {
      console.error("Game Cases failed to start", e);
    }
  })();
  return {
    name: "Game Cases",
    titleView: <div className={staticClasses?.Title}>Game Cases</div>,
    content: (
      <Guard>
        <Content />
      </Guard>
    ),
    icon: <FaCompactDisc />,
    onDismount() {
      stop();
      routerFixUndo?.();
      routerFixUndo = null;
    },
  };
});
