import base64
import json
import os

import decky

BUNDLED = os.path.join(decky.DECKY_PLUGIN_DIR, "assets", "frames")
CLASSIC = os.path.join(decky.DECKY_PLUGIN_DIR, "assets", "frames-classic")
DATA = decky.DECKY_PLUGIN_SETTINGS_DIR
USER = os.path.join(DATA, "frames")
CONFIG = os.path.join(DATA, "config.json")

DEFAULTS = {"enabled": True, "mappings": {}, "steamFallback": True, "drop": 50, "classic": False}


class Plugin:
    async def _main(self):
        os.makedirs(USER, exist_ok=True)

    async def _unload(self):
        pass

    async def get_config(self):
        try:
            with open(CONFIG) as f:
                return {**DEFAULTS, **json.load(f)}
        except Exception:
            return dict(DEFAULTS)

    async def set_config(self, cfg):
        os.makedirs(DATA, exist_ok=True)
        with open(CONFIG, "w") as f:
            json.dump(cfg, f, indent=2)
        return True

    async def list_frames(self, classic=False):
        """Bundled templates (matching headers, or the original "classic" ones), overridden by same-named PNGs in the user frames folder."""
        frames = {}
        for d in (CLASSIC if classic else BUNDLED, USER):
            if not os.path.isdir(d):
                continue
            for fn in sorted(os.listdir(d)):
                if not fn.lower().endswith(".png"):
                    continue
                name = fn[:-4]
                meta = {"label": name, "strip": 0}
                mp = os.path.join(d, name + ".json")
                if os.path.isfile(mp):
                    try:
                        with open(mp) as f:
                            meta.update(json.load(f))
                    except Exception as e:
                        decky.logger.warning(f"Bad metadata {mp}: {e}")
                with open(os.path.join(d, fn), "rb") as f:
                    meta["data"] = base64.b64encode(f.read()).decode()
                frames[name] = {"name": name, **meta}
        return list(frames.values())
